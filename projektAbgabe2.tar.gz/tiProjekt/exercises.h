#ifndef EXERCISES_H
#define EXERCISES_H
void execute_1_1();
void execute_1_2();
void execute_1_3();
void execute_1_4();
#endif