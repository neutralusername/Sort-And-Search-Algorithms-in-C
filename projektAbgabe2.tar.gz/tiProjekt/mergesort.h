#ifndef MERGESORT_H
#define MERGESORT_H
void merge_sort_array(int *array, int length, int ascending);
#endif