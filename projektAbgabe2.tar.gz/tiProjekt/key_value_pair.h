#ifndef KEY_VALUE_PAIR_H
#define KEY_VALUE_PAIR_H
struct key_value_pair {
    int key;
    char *value;
};
#endif