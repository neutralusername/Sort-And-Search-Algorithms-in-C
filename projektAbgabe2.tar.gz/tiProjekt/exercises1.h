#ifndef EXERCISES1_H
#define EXERCISES1_H
void execute_1_1();
void execute_1_2();
void execute_1_3();
void execute_1_4();
#endif