#!/bin/bash
gcc -Werror -Wextra -pedantic main.c exercises1.c exercises2.c  array_functions.c linkedlist_functions.c insertionsort.c bubblesort.c mergesort.c quicksort.c search.c quicksort_search_stdlib.c -o SortAndSearchAlgos
