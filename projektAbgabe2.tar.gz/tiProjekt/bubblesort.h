#ifndef BUBBLESORT_H
#define BUBBLESORT_H
void bubble_sort_array(int * array, int length, int ascending);
#endif