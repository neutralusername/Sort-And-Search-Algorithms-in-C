#ifndef QUICKSORT_H
#define QUICKSORT_H
void quick_sort_array(int *array, int length, int ascending);
#endif