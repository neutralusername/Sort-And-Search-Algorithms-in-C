#ifndef EXERCISES2_H
#define EXERCISES2_H
void execute_2_1();
void execute_2_2();
void execute_2_3();
#endif