struct Node {
    int data;
    struct Node * next;
};