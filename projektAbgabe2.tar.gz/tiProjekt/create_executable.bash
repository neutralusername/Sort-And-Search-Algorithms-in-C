#!/bin/bash
gcc -Werror -Wextra -pedantic main.c exercises.c array_functions.c linkedlist_functions.c insertionsort.c bubblesort.c mergesort.c quicksort.c -o SortAndSearchAlgos
